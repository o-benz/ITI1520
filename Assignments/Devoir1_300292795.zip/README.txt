Nom étudiant : Omar Benzekri
Numéro d’étudiant : 300292795
Code du cours : ITI1520
Section lab: 2

Fichiers :
✓ README.txt
✓ d1q1.py
✓ d1q2.py
✓ d1q3.py
✓ d1q4.py
✓ d1q5.py
✓ d1q6.py
