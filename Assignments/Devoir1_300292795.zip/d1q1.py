#Commentaires
#Student number: 300262795
#Student name: Omar Benzekri

lbs = int (input("Entrez le nombre de livres: "))
oz = int (input("Entrez le nombre d’onces: "))
kg = round((lbs/2.205+oz/35.274),4)
print(lbs,"livres et",oz,"onces équivalent à",kg,"kilogrammes")
