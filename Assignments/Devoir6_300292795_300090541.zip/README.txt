Nom et # d'étudiant : Omar Benzekri 300292795
Nom et # d’étudiant : Jessica Longpré 300090541
Code du cours : ITI1520
Section lab: 2

Fichiers :
✓ README.txt
✓ d5q1.py
✓ d5q2Lib.py

