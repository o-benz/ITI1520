#Commentaires
#Student number: 300262795
#Student name: Omar Benzekri

a=int(input("SVP donner la valeur de a: "))
b=int(input("SVP donner la valeur de b: "))

for a in range(a, b+1):
    print(a)
    a+1
    
