#Commentaires
#Student number: 300262795
#Student name: Omar Benzekri

import math

x=int(input("SVP Entrer un entier : "))
y=(math.sqrt(math.sqrt(x)))
    
if (y-int(y)==0):
    print(x," est un carre parfait et sa racine carree est ",math.sqrt(x))
else:
    print(x,"n'est pas un carre parfait")
