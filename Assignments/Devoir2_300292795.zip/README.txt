Nom étudiant : Omar Benzekri
Numéro d’étudiant : 300292795
Code du cours : ITI1520
Section lab: 2

Fichiers :
✓ README.txt
✓ d2q1.py
✓ d2q2.py
✓ d2q3.py
✓ d2q4.py
✓ d2q5.py
✓ d2q6.py
