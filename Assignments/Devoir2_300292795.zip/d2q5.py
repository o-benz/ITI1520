#Commentaires
#Student number: 300262795
#Student name: Omar Benzekri

feu_couleur = str(input("Quelle est le feu de circulation ? "))

if feu_couleur=="rouge":
    print("Arrêtez!")
elif feu_couleur=="vert":
    print("Avancez!")
else:
    print("Faites attention!")
