Nom et # d'étudiant : Omar Benzekri 300292795
Nom et # d’étudiant : Jessica Longpré 300090541
Code du cours : ITI1520
Section lab: 2

Fichiers :
✓ README.txt
✓ d4q1.py
✓ d4q2.py
✓ d4q3.py
✓ d4q4.py
✓ d4q5.py