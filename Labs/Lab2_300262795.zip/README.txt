Nom étudiant : Omar Benzekri
Numéro d’étudiant : 300292795
Code du cours : ITI1520

ex1: Lis deux valeurs entiers à partir du clavier et affiche le résultat de la division entière et le restant
ex2: Transforme la température du Celsius en Fahrenheit
ex3: Calcule la note finale
ex4: Calcule la surface d'un triangle