#Commentaires
#Student number: 300262795
#Student name: Omar Benzekri

x = int (input("Premier nombre entier: "))
y = int (input("Deuxième nombre entier: "))
z = x//y
w = x%y
print("Le résultat de la division est",z,"et le restant est",w)
