Nom étudiant : Omar Benzekri
Numéro d’étudiant : 300292795
Code du cours : ITI1520

• Fichiers :
✓ README.txt
✓ lab6ex1.py
✓ lab6ex2 .py
✓ lab6ex3.py
