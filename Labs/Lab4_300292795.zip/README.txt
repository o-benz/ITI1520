Nom étudiant : Omar Benzekri
Numéro d’étudiant : 300292795
Code du cours : ITI1520

• Fichiers :
✓ README.txt
✓ lab4ex1.py
✓ lab4ex2 .py
✓ lab4ex3.py
✓ lab4ex4.p
