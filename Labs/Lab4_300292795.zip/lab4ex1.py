#Commentaires
#Student number: 300262795
#Student name: Omar Benzekri

compteur = 10
while(compteur > 0): #erreur 2
    print(compteur)
    compteur = compteur - 1 #erreur 1
