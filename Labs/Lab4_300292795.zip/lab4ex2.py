#Commentaires
#Student number: 300262795
#Student name: Omar Benzekri

def imprime(n):
    i=1
    while i<=n:
        print(i, end=' ')
        i+=1

n=int(input("Entrez un entier: "))

imprime(n)
