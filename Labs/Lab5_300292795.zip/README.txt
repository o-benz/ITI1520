Nom étudiant : Omar Benzekri
Numéro d’étudiant : 300292795
Code du cours : ITI1520

• Fichiers :
✓ README.txt
✓ lab5ex1.py
✓ lab5ex2 .py
✓ lab5ex3.py
✓ lab5ex4.py
