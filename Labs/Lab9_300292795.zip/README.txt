Nom étudiant : Omar Benzekri
Numéro d’étudiant : 300292795
Code du cours : ITI1520

• Fichiers :
✓ README.txt
✓ lab8ex1.py
✓ lab8ex2 .py
✓ lab8ex3.py
