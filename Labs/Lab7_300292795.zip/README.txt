Nom étudiant : Omar Benzekri
Numéro d’étudiant : 300292795
Code du cours : ITI1520

• Fichiers :
✓ README.txt
✓ lab7ex1.py
✓ lab7ex2 .py
✓ Lab7ex3_v1.py
✓ Lab7ex3_v2.py
✓ Lab7ex3_v3.py