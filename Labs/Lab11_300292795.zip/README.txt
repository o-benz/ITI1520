Nom étudiant : Omar Benzekri
Numéro d’étudiant : 300292795
Code du cours : ITI1520

• Fichiers :
✓ README.txt
✓ lab11ex1.py
✓ lab11ex2 .py
✓ lab11ex3.py
