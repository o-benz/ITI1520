#Commentaires
#Student number: 300262795
#Student name: Omar Benzekri

age = int(input("Veuillez entrer votre âge: "))
accepte=18<=age and age<=55

if accepte:
    print("Acceptée")

else:
    print("Refusé")
