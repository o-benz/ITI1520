Nom étudiant : Omar Benzekri
Numéro d’étudiant : 300292795
Code du cours : ITI1520B

Fichiers :
✓ README.txt
✓ lab3ex1.py
✓ lab3ex2.py
✓ lab3ex3.py
✓ lab3ex4.py
